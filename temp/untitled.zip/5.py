import sys
import urllib.request
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import uic

form_class = uic.loadUiType("capstone.ui")[0]
#화면을 띄우는데 사용되는 Class 선언


class OptionWindow(QDialog) :
    def __init__(self, parent):
        super(OptionWindow, self).__init__(parent)
        option_ui = "capstone2.ui"
        uic.loadUi(option_ui, self)
        self.show()


class WindowClass(QMainWindow, form_class) :
    def __init__(self) :
        super().__init__()
        self.setupUi(self)

        #버튼에 기능을 연결하는 코드
        self.btn_1.clicked.connect(self.button1Function)
        self.btn_2.clicked.connect(self.button2Function)

    #btn_1이 눌리면 작동할 함수
    def button1Function(self) :
        OptionWindow(self)
    #btn_2가 눌리면 작동할 함수
    def button2Function(self) :
        self.qPixmapFileVar = QPixmap()
        self.qPixmapFileVar.load("증명.png")
        self.qPixmapFileVar = self.qPixmapFileVar.scaledToWidth(150)
        self.lbl_picture.setPixmap(self.qPixmapFileVar)


if __name__ == "__main__" :
    app = QApplication(sys.argv)
    myWindow = WindowClass()
    myWindow.show()
    app.exec_()