import numpy as np
import argparse
import time
import cv2

def start():

    camera = cv2.VideoCapture(0)

    while True:
        (grabbed, frame) = camera.read()

        if not grabbed:
            break

        cv2.imshow("Tracking", frame)
        time.sleep(0.025)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    camera.release()
    cv2.destroyAllWindows()
